package slokam;

public class Polo implements Car{

	
	public void wheels() {
		System.out.println("Polo car is having 4 wheels - Bridge stone");
	}
	public void steering() {
		System.out.println("Polo car is having one steering wheels");
	}
	public void engine() {
		System.out.println("Polo car is having one engine 1.2l front side");
	}
	public void breaks() {
		System.out.println("Polo car is having one normal breaking");

		
	}
}
