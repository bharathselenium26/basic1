package slokam;

public interface Car {

	public void wheels() ;
	public void steering() ;
	public void engine();
	public void breaks();
}
