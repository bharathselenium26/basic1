package slokam;

public interface X {

	public abstract void add() ;
}
