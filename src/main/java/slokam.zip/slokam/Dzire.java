package slokam;

public class Dzire implements Car{

	
	public void wheels() {
		System.out.println("This car is having 4 wheels - MRF Tyres");
	}
	public void steering() {
		System.out.println("This car is having one steering wheels");
	}
	public void engine() {
		System.out.println("This car is having one engine 1.4l front side");
	}
	public void breaks() {
		System.out.println("This car is having breaking system");
	}
}
