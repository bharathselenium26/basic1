package slokam;

public class BMW implements Car{

	public void wheels() {
	System.out.println("BMW Wheels");
		
	}

	public void steering() {
		System.out.println("BMW steering");
	}

	public void engine() {
		System.out.println("BMW engine");
		
	}

	public void breaks() {
		System.out.println("BMW breaks");
	}
	
	public void sensor() {
		System.out.println("BMW sensor");
	}

}
